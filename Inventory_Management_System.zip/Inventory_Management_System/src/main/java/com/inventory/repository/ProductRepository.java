package com.inventory.repository;

import com.inventory.model.Product;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends MongoRepository<Product, String> {

    List<Product> findBySupplierId(String supplierId);

    List<Product> findByCategoryId(String categoryId);

    List<Product> findByQuantityLessThan(int threshold);
}
