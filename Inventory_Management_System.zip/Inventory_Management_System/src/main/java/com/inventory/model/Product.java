package com.inventory.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "products")
public class Product {

    @Id
    private String productId;

    private String productName;

    private String description;

    private BigDecimal price;

    private Integer quantity;

    // Reference to Supplier (One-to-Many: one supplier → many products)
    private String supplierId;

    // Reference to Category (One-to-Many: one category → many products)
    private String categoryId;
}
