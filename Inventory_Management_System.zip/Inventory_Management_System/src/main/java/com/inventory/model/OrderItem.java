package com.inventory.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderItem {

    private String productId;

    private String productName;   // Snapshot at order time

    private Integer quantity;

    private BigDecimal unitPrice;  // Snapshot at order time

    private BigDecimal subtotal;   // quantity × unitPrice
}
