package com.inventory.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductResponse {

    private String productId;
    private String productName;
    private String description;
    private BigDecimal price;
    private Integer quantity;

    // Resolved references
    private String supplierId;
    private String supplierName;
    private String categoryId;
    private String categoryName;
}
