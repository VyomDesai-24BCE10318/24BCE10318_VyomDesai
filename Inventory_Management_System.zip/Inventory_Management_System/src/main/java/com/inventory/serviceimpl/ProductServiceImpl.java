package com.inventory.serviceimpl;

import com.inventory.dto.request.ProductRequest;
import com.inventory.dto.response.ProductResponse;
import com.inventory.exception.ResourceNotFoundException;
import com.inventory.model.Category;
import com.inventory.model.Product;
import com.inventory.model.Supplier;
import com.inventory.repository.CategoryRepository;
import com.inventory.repository.ProductRepository;
import com.inventory.repository.SupplierRepository;
import com.inventory.service.ProductService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final SupplierRepository supplierRepository;
    private final CategoryRepository categoryRepository;

    @Override
    public ProductResponse createProduct(ProductRequest request) {
        log.info("Creating product: {}", request.getProductName());

        // Validate supplier exists
        Supplier supplier = supplierRepository.findById(request.getSupplierId())
                .orElseThrow(() -> new ResourceNotFoundException("Supplier", "id", request.getSupplierId()));

        // Validate category exists
        Category category = categoryRepository.findById(request.getCategoryId())
                .orElseThrow(() -> new ResourceNotFoundException("Category", "id", request.getCategoryId()));

        Product product = Product.builder()
                .productName(request.getProductName())
                .description(request.getDescription())
                .price(request.getPrice())
                .quantity(request.getQuantity())
                .supplierId(request.getSupplierId())
                .categoryId(request.getCategoryId())
                .build();

        Product saved = productRepository.save(product);
        log.info("Product created with ID: {}", saved.getProductId());
        return mapToResponse(saved, supplier, category);
    }

    @Override
    public List<ProductResponse> getAllProducts() {
        log.info("Fetching all products");
        return productRepository.findAll()
                .stream()
                .map(product -> {
                    Supplier supplier = supplierRepository.findById(product.getSupplierId())
                            .orElse(null);
                    Category category = categoryRepository.findById(product.getCategoryId())
                            .orElse(null);
                    return mapToResponse(product, supplier, category);
                })
                .collect(Collectors.toList());
    }

    @Override
    public ProductResponse getProductById(String productId) {
        log.info("Fetching product with ID: {}", productId);
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product", "id", productId));

        Supplier supplier = supplierRepository.findById(product.getSupplierId()).orElse(null);
        Category category = categoryRepository.findById(product.getCategoryId()).orElse(null);

        return mapToResponse(product, supplier, category);
    }

    @Override
    public ProductResponse updateProduct(String productId, ProductRequest request) {
        log.info("Updating product with ID: {}", productId);

        Product existing = productRepository.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product", "id", productId));

        // Validate new supplier
        Supplier supplier = supplierRepository.findById(request.getSupplierId())
                .orElseThrow(() -> new ResourceNotFoundException("Supplier", "id", request.getSupplierId()));

        // Validate new category
        Category category = categoryRepository.findById(request.getCategoryId())
                .orElseThrow(() -> new ResourceNotFoundException("Category", "id", request.getCategoryId()));

        existing.setProductName(request.getProductName());
        existing.setDescription(request.getDescription());
        existing.setPrice(request.getPrice());
        existing.setQuantity(request.getQuantity());
        existing.setSupplierId(request.getSupplierId());
        existing.setCategoryId(request.getCategoryId());

        Product updated = productRepository.save(existing);
        log.info("Product updated: {}", productId);
        return mapToResponse(updated, supplier, category);
    }

    @Override
    public void deleteProduct(String productId) {
        log.info("Deleting product with ID: {}", productId);
        if (!productRepository.existsById(productId)) {
            throw new ResourceNotFoundException("Product", "id", productId);
        }
        productRepository.deleteById(productId);
        log.info("Product deleted: {}", productId);
    }

    // ── Mapper ────────────────────────────────────────────────────────────────
    private ProductResponse mapToResponse(Product product, Supplier supplier, Category category) {
        return ProductResponse.builder()
                .productId(product.getProductId())
                .productName(product.getProductName())
                .description(product.getDescription())
                .price(product.getPrice())
                .quantity(product.getQuantity())
                .supplierId(product.getSupplierId())
                .supplierName(supplier != null ? supplier.getSupplierName() : "Unknown")
                .categoryId(product.getCategoryId())
                .categoryName(category != null ? category.getCategoryName() : "Unknown")
                .build();
    }
}
