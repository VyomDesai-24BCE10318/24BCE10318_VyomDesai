package com.inventory.serviceimpl;

import com.inventory.dto.request.OrderItemRequest;
import com.inventory.dto.request.OrderRequest;
import com.inventory.dto.response.OrderItemResponse;
import com.inventory.dto.response.OrderResponse;
import com.inventory.exception.InsufficientStockException;
import com.inventory.exception.ResourceNotFoundException;
import com.inventory.model.Order;
import com.inventory.model.OrderItem;
import com.inventory.model.Product;
import com.inventory.repository.OrderRepository;
import com.inventory.repository.ProductRepository;
import com.inventory.service.OrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;

    @Override
    public OrderResponse createOrder(OrderRequest request) {
        log.info("Creating new order with {} item(s)", request.getOrderItems().size());

        List<OrderItem> orderItems = new ArrayList<>();
        BigDecimal totalAmount = BigDecimal.ZERO;

        // ── Step 1: Validate all products and stock before making any changes ──
        for (OrderItemRequest itemRequest : request.getOrderItems()) {
            Product product = productRepository.findById(itemRequest.getProductId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Product", "id", itemRequest.getProductId()));

            if (product.getQuantity() < itemRequest.getQuantity()) {
                throw new InsufficientStockException(
                        product.getProductName(),
                        itemRequest.getQuantity(),
                        product.getQuantity());
            }
        }

        // ── Step 2: Deduct stock and build order items ─────────────────────────
        for (OrderItemRequest itemRequest : request.getOrderItems()) {
            Product product = productRepository.findById(itemRequest.getProductId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Product", "id", itemRequest.getProductId()));

            // Deduct stock (safe — already validated above)
            int newQuantity = product.getQuantity() - itemRequest.getQuantity();
            product.setQuantity(newQuantity);
            productRepository.save(product);
            log.info("Stock deducted for product '{}': {} → {}",
                    product.getProductName(), product.getQuantity() + itemRequest.getQuantity(), newQuantity);

            // Calculate subtotal for this line item
            BigDecimal subtotal = product.getPrice()
                    .multiply(BigDecimal.valueOf(itemRequest.getQuantity()));

            OrderItem orderItem = OrderItem.builder()
                    .productId(product.getProductId())
                    .productName(product.getProductName())    // snapshot
                    .quantity(itemRequest.getQuantity())
                    .unitPrice(product.getPrice())            // snapshot
                    .subtotal(subtotal)
                    .build();

            orderItems.add(orderItem);
            totalAmount = totalAmount.add(subtotal);
        }

        // ── Step 3: Persist the order ──────────────────────────────────────────
        Order order = Order.builder()
                .orderDate(LocalDateTime.now())
                .totalAmount(totalAmount)
                .status(request.getStatus() != null ? request.getStatus() : Order.OrderStatus.PENDING)
                .orderItems(orderItems)
                .build();

        Order saved = orderRepository.save(order);
        log.info("Order created with ID: {}, total: {}", saved.getOrderId(), totalAmount);
        return mapToResponse(saved);
    }

    @Override
    public List<OrderResponse> getAllOrders() {
        log.info("Fetching all orders");
        return orderRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public OrderResponse getOrderById(String orderId) {
        log.info("Fetching order with ID: {}", orderId);
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order", "id", orderId));
        return mapToResponse(order);
    }

    @Override
    public OrderResponse updateOrder(String orderId, OrderRequest request) {
        log.info("Updating order with ID: {}", orderId);

        Order existing = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order", "id", orderId));

        // ── Step 1: Restore stock from the original order items ────────────────
        for (OrderItem oldItem : existing.getOrderItems()) {
            productRepository.findById(oldItem.getProductId()).ifPresent(product -> {
                product.setQuantity(product.getQuantity() + oldItem.getQuantity());
                productRepository.save(product);
                log.info("Stock restored for product '{}': +{}", product.getProductName(), oldItem.getQuantity());
            });
        }

        // ── Step 2: Validate new items and stock ──────────────────────────────
        for (OrderItemRequest itemRequest : request.getOrderItems()) {
            Product product = productRepository.findById(itemRequest.getProductId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Product", "id", itemRequest.getProductId()));

            if (product.getQuantity() < itemRequest.getQuantity()) {
                throw new InsufficientStockException(
                        product.getProductName(),
                        itemRequest.getQuantity(),
                        product.getQuantity());
            }
        }

        // ── Step 3: Deduct stock and build updated order items ─────────────────
        List<OrderItem> newOrderItems = new ArrayList<>();
        BigDecimal totalAmount = BigDecimal.ZERO;

        for (OrderItemRequest itemRequest : request.getOrderItems()) {
            Product product = productRepository.findById(itemRequest.getProductId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Product", "id", itemRequest.getProductId()));

            int newQuantity = product.getQuantity() - itemRequest.getQuantity();
            product.setQuantity(newQuantity);
            productRepository.save(product);

            BigDecimal subtotal = product.getPrice()
                    .multiply(BigDecimal.valueOf(itemRequest.getQuantity()));

            newOrderItems.add(OrderItem.builder()
                    .productId(product.getProductId())
                    .productName(product.getProductName())
                    .quantity(itemRequest.getQuantity())
                    .unitPrice(product.getPrice())
                    .subtotal(subtotal)
                    .build());

            totalAmount = totalAmount.add(subtotal);
        }

        // ── Step 4: Save updated order ─────────────────────────────────────────
        existing.setOrderItems(newOrderItems);
        existing.setTotalAmount(totalAmount);
        existing.setStatus(request.getStatus() != null ? request.getStatus() : existing.getStatus());

        Order updated = orderRepository.save(existing);
        log.info("Order updated: {}", orderId);
        return mapToResponse(updated);
    }

    @Override
    public void deleteOrder(String orderId) {
        log.info("Deleting order with ID: {}", orderId);

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order", "id", orderId));

        // Restore stock when an order is deleted
        for (OrderItem item : order.getOrderItems()) {
            productRepository.findById(item.getProductId()).ifPresent(product -> {
                product.setQuantity(product.getQuantity() + item.getQuantity());
                productRepository.save(product);
                log.info("Stock restored on delete for product '{}': +{}", product.getProductName(), item.getQuantity());
            });
        }

        orderRepository.deleteById(orderId);
        log.info("Order deleted: {}", orderId);
    }

    // ── Mapper ────────────────────────────────────────────────────────────────
    private OrderResponse mapToResponse(Order order) {
        List<OrderItemResponse> itemResponses = order.getOrderItems().stream()
                .map(item -> OrderItemResponse.builder()
                        .productId(item.getProductId())
                        .productName(item.getProductName())
                        .quantity(item.getQuantity())
                        .unitPrice(item.getUnitPrice())
                        .subtotal(item.getSubtotal())
                        .build())
                .collect(Collectors.toList());

        return OrderResponse.builder()
                .orderId(order.getOrderId())
                .orderDate(order.getOrderDate())
                .totalAmount(order.getTotalAmount())
                .status(order.getStatus())
                .orderItems(itemResponses)
                .build();
    }
}
