package com.inventory.serviceimpl;

import com.inventory.dto.request.SupplierRequest;
import com.inventory.dto.response.SupplierResponse;
import com.inventory.exception.DuplicateResourceException;
import com.inventory.exception.ResourceNotFoundException;
import com.inventory.model.Supplier;
import com.inventory.repository.SupplierRepository;
import com.inventory.service.SupplierService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class SupplierServiceImpl implements SupplierService {

    private final SupplierRepository supplierRepository;

    @Override
    public SupplierResponse createSupplier(SupplierRequest request) {
        log.info("Creating supplier with email: {}", request.getEmail());

        if (supplierRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Supplier", "email", request.getEmail());
        }

        Supplier supplier = Supplier.builder()
                .supplierName(request.getSupplierName())
                .email(request.getEmail())
                .phone(request.getPhone())
                .address(request.getAddress())
                .build();

        Supplier saved = supplierRepository.save(supplier);
        log.info("Supplier created with ID: {}", saved.getSupplierId());
        return mapToResponse(saved);
    }

    @Override
    public List<SupplierResponse> getAllSuppliers() {
        log.info("Fetching all suppliers");
        return supplierRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public SupplierResponse getSupplierById(String supplierId) {
        log.info("Fetching supplier with ID: {}", supplierId);
        Supplier supplier = supplierRepository.findById(supplierId)
                .orElseThrow(() -> new ResourceNotFoundException("Supplier", "id", supplierId));
        return mapToResponse(supplier);
    }

    @Override
    public SupplierResponse updateSupplier(String supplierId, SupplierRequest request) {
        log.info("Updating supplier with ID: {}", supplierId);

        Supplier existing = supplierRepository.findById(supplierId)
                .orElseThrow(() -> new ResourceNotFoundException("Supplier", "id", supplierId));

        // Check if another supplier already uses the new email
        if (!existing.getEmail().equalsIgnoreCase(request.getEmail())
                && supplierRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Supplier", "email", request.getEmail());
        }

        existing.setSupplierName(request.getSupplierName());
        existing.setEmail(request.getEmail());
        existing.setPhone(request.getPhone());
        existing.setAddress(request.getAddress());

        Supplier updated = supplierRepository.save(existing);
        log.info("Supplier updated: {}", supplierId);
        return mapToResponse(updated);
    }

    @Override
    public void deleteSupplier(String supplierId) {
        log.info("Deleting supplier with ID: {}", supplierId);
        if (!supplierRepository.existsById(supplierId)) {
            throw new ResourceNotFoundException("Supplier", "id", supplierId);
        }
        supplierRepository.deleteById(supplierId);
        log.info("Supplier deleted: {}", supplierId);
    }

    // ── Mapper ────────────────────────────────────────────────────────────────
    private SupplierResponse mapToResponse(Supplier supplier) {
        return SupplierResponse.builder()
                .supplierId(supplier.getSupplierId())
                .supplierName(supplier.getSupplierName())
                .email(supplier.getEmail())
                .phone(supplier.getPhone())
                .address(supplier.getAddress())
                .build();
    }
}
