package com.inventory.service;

import com.inventory.dto.request.OrderRequest;
import com.inventory.dto.response.OrderResponse;

import java.util.List;

public interface OrderService {

    OrderResponse createOrder(OrderRequest request);

    List<OrderResponse> getAllOrders();

    OrderResponse getOrderById(String orderId);

    OrderResponse updateOrder(String orderId, OrderRequest request);

    void deleteOrder(String orderId);
}
