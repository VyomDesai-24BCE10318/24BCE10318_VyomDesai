package com.inventory.service;

import com.inventory.dto.request.SupplierRequest;
import com.inventory.dto.response.SupplierResponse;

import java.util.List;

public interface SupplierService {

    SupplierResponse createSupplier(SupplierRequest request);

    List<SupplierResponse> getAllSuppliers();

    SupplierResponse getSupplierById(String supplierId);

    SupplierResponse updateSupplier(String supplierId, SupplierRequest request);

    void deleteSupplier(String supplierId);
}
