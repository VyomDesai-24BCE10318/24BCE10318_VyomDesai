package com.inventory.service;

import com.inventory.dto.request.CategoryRequest;
import com.inventory.dto.response.CategoryResponse;

import java.util.List;

public interface CategoryService {

    CategoryResponse createCategory(CategoryRequest request);

    List<CategoryResponse> getAllCategories();

    CategoryResponse getCategoryById(String categoryId);

    CategoryResponse updateCategory(String categoryId, CategoryRequest request);

    void deleteCategory(String categoryId);
}
